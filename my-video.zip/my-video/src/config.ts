/**
 * ============================================================
 *  EDIT THIS FILE ONLY.  Change the text between the quotes.
 *  Save the file and the video preview updates by itself.
 * ============================================================
 */

export type Project = {
  title: string;
  category: string;
  client: string;
  year: string;
  description: string;
  /** Accent color for the placeholder screen */
  color: string;
  /**
   * OPTIONAL: your real work. Put an image (.jpg/.png) or video (.mp4)
   * inside the "public" folder and write its file name here,
   * for example: media: "project1.mp4"
   */
  media?: string;
};

const projects: Project[] = [
  {
    title: "Brand Launch Film",
    category: "Motion Graphics",
    client: "Client Name",
    year: "2026",
    description:
      "A clean animated launch video that explains the product in 30 seconds.",
    color: "#4F46E5",
    // media: "project1.mp4",
  },
  {
    title: "Explainer Video",
    category: "2D Animation",
    client: "Client Name",
    year: "2025",
    description:
      "Simple shapes and smooth motion that turn a complex service into a clear story.",
    color: "#FF6B4A",
    // media: "project2.mp4",
  },
  {
    title: "Social Media Pack",
    category: "Visual Identity",
    client: "Client Name",
    year: "2025",
    description:
      "A consistent set of animated posts and intros that keep the brand recognisable.",
    color: "#0EA5A4",
    // media: "project3.mp4",
  },
];

export const config = {
  name: "Your Name",
  role: "Motion Designer",
  tagline: "Clean visuals that make ideas move.",
  label: "Portfolio",
  year: "2026",

  colors: {
    bg: "#F6F5F1",
    ink: "#111214",
    muted: "#6B6F76",
    accent: "#4F46E5",
    accent2: "#FF6B4A",
    card: "#FFFFFF",
    line: "#E2E0D8",
  },

  about: {
    headline: "I turn complex ideas into clear, moving stories.",
    text: "I design motion graphics for brands and creators who want a clean, modern look. Every video is planned, animated and delivered with care.",
    keywords: ["Clean", "Purposeful", "On time"],
  },

  services: [
    {
      title: "Motion Graphics",
      description: "Smooth animated visuals for ads, intros and product videos.",
    },
    {
      title: "Explainer Videos",
      description: "Simple stories that make your service easy to understand.",
    },
    {
      title: "Brand Animation",
      description: "Logos, titles and lower thirds that match your identity.",
    },
    {
      title: "Social Content",
      description: "Short, eye-catching clips made for every platform.",
    },
  ],

  projects,

  stats: [
    {value: 150, suffix: "+", label: "Projects delivered"},
    {value: 60, suffix: "+", label: "Happy clients"},
    {value: 5, suffix: "", label: "Years of experience"},
  ],

  process: [
    {title: "Discover", description: "We talk about your goals and audience."},
    {title: "Design", description: "Style frames and a clear storyboard."},
    {title: "Animate", description: "Motion, sound and polish."},
    {title: "Deliver", description: "Final files in every format you need."},
  ],

  contact: {
    headline: "Let's create something great together.",
    email: "hello@yourname.com",
    website: "www.yourname.com",
    social: "@yourname",
  },
};
