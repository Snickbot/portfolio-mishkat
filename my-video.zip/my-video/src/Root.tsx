import React from "react";
import {Composition} from "remotion";
import {Portfolio} from "./Portfolio";
import {FPS, HEIGHT, TOTAL, WIDTH} from "./timing";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="Portfolio"
      component={Portfolio}
      durationInFrames={TOTAL}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
    />
  );
};
