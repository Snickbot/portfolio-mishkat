import React from "react";
import {AbsoluteFill, Audio, interpolate, Sequence, Series, staticFile} from "remotion";
import {config} from "./config";
import {Background, C, FONT} from "./common";
import {D, sceneStarts, TOTAL} from "./timing";
import {Intro} from "./scenes/Intro";
import {About} from "./scenes/About";
import {Services} from "./scenes/Services";
import {ProjectScene} from "./scenes/Project";
import {Stats} from "./scenes/Stats";
import {Process} from "./scenes/Process";
import {Outro} from "./scenes/Outro";

export const Portfolio: React.FC = () => {
  const total = config.projects.length;

  return (
    <AbsoluteFill style={{backgroundColor: C.bg, fontFamily: FONT}}>
      <Background />

      <Series>
        <Series.Sequence durationInFrames={D.intro}>
          <Intro duration={D.intro} />
        </Series.Sequence>
        <Series.Sequence durationInFrames={D.about}>
          <About duration={D.about} />
        </Series.Sequence>
        <Series.Sequence durationInFrames={D.services}>
          <Services duration={D.services} />
        </Series.Sequence>
        {config.projects.map((p, i) => (
          <Series.Sequence key={i} durationInFrames={D.project}>
            <ProjectScene project={p} index={i} total={total} duration={D.project} />
          </Series.Sequence>
        ))}
        <Series.Sequence durationInFrames={D.stats}>
          <Stats duration={D.stats} />
        </Series.Sequence>
        <Series.Sequence durationInFrames={D.process}>
          <Process duration={D.process} />
        </Series.Sequence>
        <Series.Sequence durationInFrames={D.outro}>
          <Outro duration={D.outro} />
        </Series.Sequence>
      </Series>

      {/* Background music with fade in / fade out */}
      <Audio
        src={staticFile("music.mp3")}
        volume={(f) =>
          interpolate(f, [0, 45, TOTAL - 150, TOTAL], [0, 0.6, 0.6, 0], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          })
        }
      />

      {/* Soft whoosh at every scene change */}
      {sceneStarts.slice(1).map((f) => (
        <Sequence key={f} from={Math.max(0, f - 8)} durationInFrames={45}>
          <Audio src={staticFile("whoosh.wav")} volume={0.3} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
