import React from "react";
import {Easing, interpolate, useCurrentFrame} from "remotion";
import {config} from "../config";
import {C, Label, MaskText, Reveal, SceneFade} from "../common";

export const Intro: React.FC<{duration: number}> = ({duration}) => {
  const frame = useCurrentFrame();

  const ease = Easing.out(Easing.cubic);
  const draw = interpolate(frame, [0, 80], [0, 1], {
    extrapolateRight: "clamp",
    easing: ease,
  });
  const lineW = interpolate(frame, [60, 105], [0, 260], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: ease,
  });

  const cx = 1450;
  const cy = 540;
  const R1 = 360;
  const R2 = 230;
  const c1 = 2 * Math.PI * R1;
  const c2 = 2 * Math.PI * R2;
  const a1 = frame * 0.022;
  const a2 = -frame * 0.035;

  return (
    <SceneFade duration={duration} fadeIn={1}>
      <svg
        width={1920}
        height={1080}
        viewBox="0 0 1920 1080"
        style={{position: "absolute", left: 0, top: 0}}
      >
        <circle
          cx={cx}
          cy={cy}
          r={R1}
          fill="none"
          stroke={C.ink}
          strokeWidth={2}
          strokeDasharray={c1}
          strokeDashoffset={c1 * (1 - draw)}
          transform={`rotate(-90 ${cx} ${cy})`}
        />
        <circle
          cx={cx}
          cy={cy}
          r={R2}
          fill="none"
          stroke={C.line}
          strokeWidth={2}
          strokeDasharray={c2}
          strokeDashoffset={c2 * (1 - draw)}
          transform={`rotate(-90 ${cx} ${cy})`}
        />
        <circle cx={cx} cy={cy} r={110 * draw} fill={C.accent} />
        <circle
          cx={cx + Math.cos(a1) * R1}
          cy={cy + Math.sin(a1) * R1}
          r={16}
          fill={C.accent2}
          opacity={draw}
        />
        <circle
          cx={cx + Math.cos(a2) * R2}
          cy={cy + Math.sin(a2) * R2}
          r={11}
          fill={C.ink}
          opacity={draw}
        />
      </svg>

      <div
        style={{
          position: "absolute",
          left: 160,
          top: 0,
          bottom: 0,
          width: 1000,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
        }}
      >
        <Label delay={10}>
          {config.label} — {config.year}
        </Label>
        <div style={{height: 28}} />
        <MaskText
          delay={22}
          style={{fontSize: 150, fontWeight: 800, letterSpacing: -5, lineHeight: 1.02, color: C.ink}}
        >
          {config.name}
        </MaskText>
        <MaskText
          delay={36}
          style={{fontSize: 58, fontWeight: 500, color: C.accent, lineHeight: 1.2}}
        >
          {config.role}
        </MaskText>
        <div style={{height: 36}} />
        <div style={{width: lineW, height: 4, background: C.ink, borderRadius: 2}} />
        <div style={{height: 32}} />
        <Reveal delay={80} style={{fontSize: 36, color: C.muted, fontWeight: 400}}>
          {config.tagline}
        </Reveal>
      </div>
    </SceneFade>
  );
};
