import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {config} from "../config";
import {C, Label, Pop, Reveal, SceneFade, WordReveal, useEnter} from "../common";

const COL = 400; // width of one step column
const LINE_Y = 36; // vertical center of circles inside the track

const Step: React.FC<{
  index: number;
  title: string;
  description: string;
}> = ({index, title, description}) => {
  const delay = 40 + index * 45;
  const p = useEnter(delay);
  return (
    <div style={{width: COL, position: "relative"}}>
      <div
        style={{
          width: 72,
          height: 72,
          borderRadius: "50%",
          background: C.accent,
          color: "#fff",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 30,
          fontWeight: 700,
          transform: `scale(${p})`,
        }}
      >
        {index + 1}
      </div>
      <Reveal delay={delay + 8} style={{marginTop: 36}}>
        <div style={{fontSize: 52, fontWeight: 700, letterSpacing: -1.5, color: C.ink}}>{title}</div>
        <div style={{fontSize: 28, lineHeight: 1.45, color: C.muted, marginTop: 14, paddingRight: 40}}>
          {description}
        </div>
      </Reveal>
    </div>
  );
};

export const Process: React.FC<{duration: number}> = ({duration}) => {
  const frame = useCurrentFrame();
  const steps = config.process;
  const trackWidth = COL * steps.length;
  const line = interpolate(
    frame,
    [40, 40 + 45 * (steps.length - 1)],
    [0, COL * (steps.length - 1)],
    {extrapolateLeft: "clamp", extrapolateRight: "clamp"}
  );

  return (
    <SceneFade duration={duration}>
      <div style={{position: "absolute", left: 160, top: 120}}>
        <Label delay={4}>05 — Process</Label>
        <div style={{height: 22}} />
        <WordReveal
          text="A simple, clear workflow"
          delay={12}
          stagger={5}
          style={{fontSize: 90, fontWeight: 700, letterSpacing: -3, color: C.ink}}
        />
      </div>

      <div style={{position: "absolute", left: 160, top: 450, width: trackWidth}}>
        {/* base line + animated line */}
        <div
          style={{
            position: "absolute",
            left: 36,
            top: LINE_Y - 2,
            width: COL * (steps.length - 1),
            height: 4,
            background: C.line,
            borderRadius: 2,
          }}
        />
        <div
          style={{
            position: "absolute",
            left: 36,
            top: LINE_Y - 2,
            width: line,
            height: 4,
            background: C.accent,
            borderRadius: 2,
          }}
        />
        <div style={{position: "relative", display: "flex"}}>
          {steps.map((s, i) => (
            <Step key={i} index={i} title={s.title} description={s.description} />
          ))}
        </div>
      </div>

      {steps.map((_, i) => (
        <Pop key={i} at={40 + i * 45} />
      ))}
    </SceneFade>
  );
};
