import React from "react";
import {interpolate, interpolateColors, useCurrentFrame} from "remotion";
import {config} from "../config";
import {C, Label, Pop, SceneFade, WordReveal, useEnter} from "../common";

const Icon: React.FC<{index: number; color: string}> = ({index, color}) => {
  const frame = useCurrentFrame();
  const rot = frame * 0.8;
  const s = 90;
  return (
    <svg width={s} height={s} viewBox="0 0 90 90">
      {index % 4 === 0 && (
        <>
          <circle cx={45} cy={45} r={30} fill="none" stroke={color} strokeWidth={5} />
          <circle
            cx={45 + Math.cos(frame * 0.06) * 30}
            cy={45 + Math.sin(frame * 0.06) * 30}
            r={9}
            fill={color}
          />
        </>
      )}
      {index % 4 === 1 && (
        <rect
          x={20}
          y={20}
          width={50}
          height={50}
          rx={12}
          fill="none"
          stroke={color}
          strokeWidth={5}
          transform={`rotate(${rot} 45 45)`}
        />
      )}
      {index % 4 === 2 && (
        <polygon
          points="45,12 80,74 10,74"
          fill="none"
          stroke={color}
          strokeWidth={5}
          strokeLinejoin="round"
          transform={`rotate(${Math.sin(frame * 0.04) * 20} 45 55)`}
        />
      )}
      {index % 4 === 3 &&
        [0, 1, 2].map((b) => {
          const h = 20 + (Math.sin(frame * 0.08 + b * 1.4) + 1) * 18;
          return <rect key={b} x={14 + b * 24} y={78 - h} width={16} height={h} rx={5} fill={color} />;
        })}
    </svg>
  );
};

const Card: React.FC<{
  index: number;
  title: string;
  description: string;
}> = ({index, title, description}) => {
  const frame = useCurrentFrame();
  const delay = 50 + index * 24;
  const p = useEnter(delay);

  // highlight cards one after another
  const local = frame - (230 + index * 90);
  const amount = interpolate(local, [0, 16, 74, 90], [0, 1, 1, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  const bg = interpolateColors(amount, [0, 1], [C.card, C.accent]);
  const fg = interpolateColors(amount, [0, 1], [C.ink, "#FFFFFF"]);
  const sub = interpolateColors(amount, [0, 1], [C.muted, "rgba(255,255,255,0.85)"]);
  const iconColor = interpolateColors(amount, [0, 1], [C.accent, "#FFFFFF"]);
  const border = interpolateColors(amount, [0, 1], [C.line, C.accent]);

  return (
    <div
      style={{
        width: 376,
        height: 500,
        boxSizing: "border-box",
        padding: 40,
        borderRadius: 32,
        background: bg,
        border: `2px solid ${border}`,
        opacity: p,
        transform: `translateY(${(1 - p) * 70}px) scale(${1 + amount * 0.03})`,
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
      }}
    >
      <div>
        <div style={{fontSize: 24, fontWeight: 600, color: sub, letterSpacing: 4}}>
          0{index + 1}
        </div>
        <div style={{height: 28}} />
        <Icon index={index} color={iconColor} />
      </div>
      <div>
        <div style={{fontSize: 40, fontWeight: 700, color: fg, lineHeight: 1.1, letterSpacing: -1}}>
          {title}
        </div>
        <div style={{height: 16}} />
        <div style={{fontSize: 24, lineHeight: 1.45, color: sub}}>{description}</div>
      </div>
    </div>
  );
};

export const Services: React.FC<{duration: number}> = ({duration}) => {
  return (
    <SceneFade duration={duration}>
      <div style={{position: "absolute", left: 160, top: 110}}>
        <Label delay={4}>02 — Services</Label>
        <div style={{height: 22}} />
        <WordReveal
          text="What I can do for you"
          delay={12}
          stagger={4}
          style={{fontSize: 84, fontWeight: 700, letterSpacing: -2.5, color: C.ink}}
        />
      </div>

      <div
        style={{
          position: "absolute",
          left: 160,
          top: 400,
          display: "flex",
          gap: 32,
        }}
      >
        {config.services.map((s, i) => (
          <Card key={i} index={i} title={s.title} description={s.description} />
        ))}
      </div>

      {config.services.map((_, i) => (
        <Pop key={i} at={50 + i * 24} />
      ))}
    </SceneFade>
  );
};
