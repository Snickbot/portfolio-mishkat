import React from "react";
import {
  AbsoluteFill,
  Easing,
  Img,
  interpolate,
  OffthreadVideo,
  staticFile,
  useCurrentFrame,
} from "remotion";
import type {Project as ProjectType} from "../config";
import {C, Label, MaskText, Reveal, SceneFade, useEnter} from "../common";

const Placeholder: React.FC<{project: ProjectType}> = ({project}) => {
  const frame = useCurrentFrame();
  const bars = [0, 1, 2, 3, 4];
  return (
    <AbsoluteFill
      style={{background: `linear-gradient(135deg, ${project.color} 0%, ${C.ink} 130%)`}}
    >
      {[0, 1, 2].map((i) => {
        const size = 260 + i * 140;
        const x = 500 + Math.sin(frame * 0.015 + i * 2) * 260;
        const y = 281 + Math.cos(frame * 0.012 + i * 1.7) * 140;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: x - size / 2,
              top: y - size / 2,
              width: size,
              height: size,
              borderRadius: "50%",
              border: "3px solid rgba(255,255,255,0.35)",
              background: i === 0 ? "rgba(255,255,255,0.12)" : "transparent",
            }}
          />
        );
      })}
      <div
        style={{
          position: "absolute",
          left: 60,
          bottom: 56,
          display: "flex",
          alignItems: "flex-end",
          gap: 14,
        }}
      >
        {bars.map((b) => {
          const h = 40 + (Math.sin(frame * 0.07 + b * 0.9) + 1) * 40;
          return (
            <div
              key={b}
              style={{width: 26, height: h, borderRadius: 8, background: "rgba(255,255,255,0.8)"}}
            />
          );
        })}
      </div>
      <div
        style={{
          position: "absolute",
          inset: 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          color: "#fff",
          textAlign: "center",
        }}
      >
        <div style={{fontSize: 56, fontWeight: 800, letterSpacing: -1.5}}>{project.title}</div>
        <div style={{fontSize: 22, marginTop: 14, opacity: 0.75}}>
          Your work goes here — see README
        </div>
      </div>
    </AbsoluteFill>
  );
};

const Media: React.FC<{project: ProjectType}> = ({project}) => {
  if (!project.media) {
    return <Placeholder project={project} />;
  }
  const isVideo = /\.(mp4|webm|mov)$/i.test(project.media);
  const style: React.CSSProperties = {width: "100%", height: "100%", objectFit: "cover"};
  return isVideo ? (
    <OffthreadVideo src={staticFile(project.media)} muted style={style} />
  ) : (
    <Img src={staticFile(project.media)} style={style} />
  );
};

export const ProjectScene: React.FC<{
  project: ProjectType;
  index: number;
  total: number;
  duration: number;
}> = ({project, index, total, duration}) => {
  const frame = useCurrentFrame();
  const reveal = interpolate(frame, [8, 50], [1, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.out(Easing.cubic),
  });
  const zoom = interpolate(frame, [0, duration], [1.12, 1.0], {
    extrapolateRight: "clamp",
  });
  const progress = interpolate(frame, [0, duration], [0, 100], {
    extrapolateRight: "clamp",
  });
  const num = String(index + 1).padStart(2, "0");
  const tot = String(total).padStart(2, "0");
  const framePop = useEnter(8);

  return (
    <SceneFade duration={duration}>
      {/* text column */}
      <div
        style={{
          position: "absolute",
          left: 160,
          top: 0,
          bottom: 0,
          width: 580,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
        }}
      >
        <Label delay={6}>03 — Selected Work</Label>
        <div style={{height: 26}} />
        <Reveal
          delay={12}
          style={{display: "flex", alignItems: "baseline", gap: 14}}
        >
          <span style={{fontSize: 120, fontWeight: 800, color: C.accent, letterSpacing: -4, lineHeight: 1}}>
            {num}
          </span>
          <span style={{fontSize: 30, fontWeight: 500, color: C.muted}}>/ {tot}</span>
        </Reveal>
        <div style={{height: 18}} />
        <MaskText
          delay={22}
          style={{fontSize: 70, fontWeight: 800, lineHeight: 1.05, letterSpacing: -2.5, color: C.ink}}
        >
          {project.title}
        </MaskText>
        <div style={{height: 22}} />
        <Reveal
          delay={34}
          style={{
            alignSelf: "flex-start",
            padding: "10px 26px",
            borderRadius: 999,
            background: C.ink,
            color: "#fff",
            fontSize: 24,
            fontWeight: 600,
          }}
        >
          {project.category}
        </Reveal>
        <div style={{height: 30}} />
        <Reveal delay={46} style={{fontSize: 30, lineHeight: 1.5, color: C.muted}}>
          {project.description}
        </Reveal>
        <div style={{height: 40}} />
        <Reveal delay={60} style={{display: "flex", gap: 56}}>
          <div>
            <div style={{fontSize: 18, letterSpacing: 4, color: C.muted, fontWeight: 600}}>CLIENT</div>
            <div style={{fontSize: 28, fontWeight: 600, color: C.ink, marginTop: 6}}>{project.client}</div>
          </div>
          <div>
            <div style={{fontSize: 18, letterSpacing: 4, color: C.muted, fontWeight: 600}}>YEAR</div>
            <div style={{fontSize: 28, fontWeight: 600, color: C.ink, marginTop: 6}}>{project.year}</div>
          </div>
        </Reveal>
        <div style={{height: 44}} />
        <div style={{height: 4, background: C.line, borderRadius: 2, width: "100%"}}>
          <div
            style={{
              height: 4,
              width: `${progress}%`,
              background: C.accent,
              borderRadius: 2,
            }}
          />
        </div>
      </div>

      {/* device frame */}
      <div
        style={{
          position: "absolute",
          left: 800,
          top: 258,
          width: 1000,
          height: 563,
          opacity: framePop > 0.01 ? 1 : 0,
          clipPath: `inset(0% ${reveal * 100}% 0% 0% round 28px)`,
          boxShadow: "0 40px 90px rgba(17,18,20,0.25)",
          background: C.card,
        }}
      >
        <div
          style={{
            width: "100%",
            height: "100%",
            transform: `scale(${zoom})`,
            transformOrigin: "center center",
          }}
        >
          <Media project={project} />
        </div>
      </div>
    </SceneFade>
  );
};
