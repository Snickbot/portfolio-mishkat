import React from "react";
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from "remotion";
import {config} from "../config";
import {C, Reveal, WordReveal} from "../common";

export const Outro: React.FC<{duration: number}> = ({duration}) => {
  const frame = useCurrentFrame();

  const radius = interpolate(frame, [0, 36], [0, 150], {
    extrapolateRight: "clamp",
    easing: Easing.out(Easing.cubic),
  });
  const endFade = interpolate(frame, [duration - 40, duration], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const spin = frame * 0.25;

  const rows = [
    {k: "EMAIL", v: config.contact.email},
    {k: "WEBSITE", v: config.contact.website},
    {k: "SOCIAL", v: config.contact.social},
  ];

  return (
    <AbsoluteFill>
      <AbsoluteFill style={{background: C.accent, clipPath: `circle(${radius}% at 50% 50%)`}}>
        {/* decorative rings */}
        <svg
          width={1920}
          height={1080}
          viewBox="0 0 1920 1080"
          style={{position: "absolute", left: 0, top: 0}}
        >
          <circle
            cx={1600}
            cy={180}
            r={260}
            fill="none"
            stroke="rgba(255,255,255,0.25)"
            strokeWidth={2}
            strokeDasharray="10 18"
            transform={`rotate(${spin} 1600 180)`}
          />
          <circle cx={1600} cy={180} r={120} fill="rgba(255,255,255,0.12)" />
          <circle
            cx={260}
            cy={920}
            r={200}
            fill="none"
            stroke="rgba(255,255,255,0.25)"
            strokeWidth={2}
            strokeDasharray="10 18"
            transform={`rotate(${-spin} 260 920)`}
          />
        </svg>

        <div
          style={{
            position: "absolute",
            left: 160,
            right: 160,
            top: 0,
            bottom: 0,
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            color: "#fff",
          }}
        >
          <Reveal delay={20} style={{fontSize: 26, letterSpacing: 6, fontWeight: 600, opacity: 0.8}}>
            THANK YOU
          </Reveal>
          <div style={{height: 26}} />
          <WordReveal
            text={config.contact.headline}
            delay={28}
            stagger={4}
            style={{fontSize: 116, fontWeight: 800, lineHeight: 1.04, letterSpacing: -4, maxWidth: 1300}}
          />
          <div style={{height: 56}} />
          <div style={{display: "flex", gap: 90}}>
            {rows.map((r, i) => (
              <Reveal key={r.k} delay={80 + i * 12} y={20}>
                <div style={{fontSize: 18, letterSpacing: 5, fontWeight: 600, opacity: 0.7}}>{r.k}</div>
                <div style={{fontSize: 36, fontWeight: 600, marginTop: 8}}>{r.v}</div>
              </Reveal>
            ))}
          </div>
        </div>
      </AbsoluteFill>
      <AbsoluteFill style={{background: C.ink, opacity: endFade}} />
    </AbsoluteFill>
  );
};
