import React from "react";
import {Easing, interpolate, useCurrentFrame} from "remotion";
import {config} from "../config";
import {C, Label, Pop, SceneFade, WordReveal, useEnter} from "../common";

const Stat: React.FC<{
  index: number;
  value: number;
  suffix: string;
  label: string;
}> = ({index, value, suffix, label}) => {
  const frame = useCurrentFrame();
  const start = 40 + index * 22;
  const enter = useEnter(start - 10);
  const count = interpolate(frame, [start, start + 80], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.out(Easing.cubic),
  });

  return (
    <div
      style={{
        flex: 1,
        height: 420,
        boxSizing: "border-box",
        padding: 48,
        borderRadius: 32,
        background: C.card,
        border: `2px solid ${C.line}`,
        opacity: enter,
        transform: `translateY(${(1 - enter) * 60}px)`,
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
      }}
    >
      <div
        style={{
          fontSize: 170,
          fontWeight: 800,
          letterSpacing: -6,
          lineHeight: 1,
          color: C.ink,
        }}
      >
        {Math.round(value * count)}
        <span style={{color: C.accent}}>{suffix}</span>
      </div>
      <div>
        <div style={{height: 6, width: `${count * 100}%`, background: C.accent, borderRadius: 3}} />
        <div style={{height: 22}} />
        <div style={{fontSize: 34, color: C.muted, fontWeight: 500}}>{label}</div>
      </div>
    </div>
  );
};

export const Stats: React.FC<{duration: number}> = ({duration}) => {
  return (
    <SceneFade duration={duration}>
      <div style={{position: "absolute", left: 160, top: 120}}>
        <Label delay={4}>04 — Results</Label>
        <div style={{height: 22}} />
        <WordReveal
          text="By the numbers"
          delay={12}
          stagger={5}
          style={{fontSize: 90, fontWeight: 700, letterSpacing: -3, color: C.ink}}
        />
      </div>
      <div
        style={{
          position: "absolute",
          left: 160,
          right: 160,
          top: 430,
          display: "flex",
          gap: 36,
        }}
      >
        {config.stats.map((s, i) => (
          <Stat key={i} index={i} value={s.value} suffix={s.suffix} label={s.label} />
        ))}
      </div>
      {config.stats.map((_, i) => (
        <Pop key={i} at={30 + i * 22} />
      ))}
    </SceneFade>
  );
};
