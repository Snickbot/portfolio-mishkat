import React from "react";
import {useCurrentFrame} from "remotion";
import {config} from "../config";
import {C, Label, Reveal, SceneFade, WordReveal, useEnter} from "../common";

export const About: React.FC<{duration: number}> = ({duration}) => {
  const frame = useCurrentFrame();
  const grow = useEnter(10);

  const cx = 1410;
  const cy = 540;
  const orbits = [
    {r: 130, speed: 0.035, size: 13, color: C.accent},
    {r: 230, speed: -0.022, size: 17, color: C.accent2},
    {r: 330, speed: 0.013, size: 21, color: C.ink},
  ];
  const pulse = 1 + Math.sin(frame * 0.07) * 0.05;

  return (
    <SceneFade duration={duration}>
      <svg
        width={1920}
        height={1080}
        viewBox="0 0 1920 1080"
        style={{position: "absolute", left: 0, top: 0}}
      >
        {orbits.map((o, i) => {
          const rr = o.r * grow;
          const a = frame * o.speed + i * 2;
          return (
            <g key={i}>
              <circle cx={cx} cy={cy} r={rr} fill="none" stroke={C.line} strokeWidth={2} />
              <circle
                cx={cx + Math.cos(a) * rr}
                cy={cy + Math.sin(a) * rr}
                r={o.size}
                fill={o.color}
              />
            </g>
          );
        })}
        <circle cx={cx} cy={cy} r={62 * grow * pulse} fill={C.accent} />
      </svg>

      <div
        style={{
          position: "absolute",
          left: 160,
          top: 0,
          bottom: 0,
          width: 900,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
        }}
      >
        <Label delay={6}>01 — About</Label>
        <div style={{height: 32}} />
        <WordReveal
          text={config.about.headline}
          delay={16}
          stagger={4}
          style={{fontSize: 78, fontWeight: 700, lineHeight: 1.08, letterSpacing: -2, color: C.ink}}
        />
        <div style={{height: 36}} />
        <Reveal
          delay={90}
          style={{fontSize: 32, lineHeight: 1.5, color: C.muted, maxWidth: 800}}
        >
          {config.about.text}
        </Reveal>
        <div style={{height: 44}} />
        <div style={{display: "flex", gap: 18}}>
          {config.about.keywords.map((k, i) => (
            <Reveal
              key={k}
              delay={150 + i * 14}
              y={18}
              style={{
                padding: "14px 30px",
                borderRadius: 999,
                border: `2px solid ${C.ink}`,
                fontSize: 26,
                fontWeight: 600,
                color: C.ink,
              }}
            >
              {k}
            </Reveal>
          ))}
        </div>
      </div>
    </SceneFade>
  );
};
