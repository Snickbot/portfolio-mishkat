import {config} from "./config";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

const sec = (s: number) => Math.round(s * FPS);

const projectCount = Math.max(1, config.projects.length);

/** Scene lengths in frames. Total = 120 seconds with 3 projects. */
export const D = {
  intro: sec(8),
  about: sec(14),
  services: sec(20),
  project: Math.floor(sec(48) / projectCount),
  stats: sec(12),
  process: sec(10),
  outro: sec(8),
};

const order: number[] = [
  D.intro,
  D.about,
  D.services,
  ...config.projects.map(() => D.project),
  D.stats,
  D.process,
  D.outro,
];

export const TOTAL = order.reduce((a, b) => a + b, 0);

/** Frame where each scene starts (used for transition sounds). */
export const sceneStarts: number[] = order.reduce<number[]>((acc, len, i) => {
  acc.push(i === 0 ? 0 : acc[i - 1] + order[i - 1]);
  return acc;
}, []);
