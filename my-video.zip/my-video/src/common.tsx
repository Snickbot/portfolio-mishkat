import React from "react";
import {
  AbsoluteFill,
  Audio,
  interpolate,
  Sequence,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import {loadFont} from "@remotion/google-fonts/Inter";
import {config} from "./config";

const {fontFamily} = loadFont("normal", {
  weights: ["400", "500", "600", "700", "800"],
  subsets: ["latin"],
});

export const FONT = `${fontFamily}, "Helvetica Neue", Arial, sans-serif`;
export const C = config.colors;

/** 0 -> 1 smooth spring (no bounce). Starts after `delay` frames. */
export const useEnter = (delay = 0, damping = 200): number => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: frame - delay, fps, config: {damping}});
};

/** Fades a whole scene in and out. */
export const SceneFade: React.FC<{
  duration: number;
  fadeIn?: number;
  fadeOut?: number;
  children: React.ReactNode;
}> = ({duration, fadeIn = 14, fadeOut = 14, children}) => {
  const frame = useCurrentFrame();
  const fi = Math.max(1, fadeIn);
  const fo = Math.max(1, fadeOut);
  const opacity = interpolate(
    frame,
    [0, fi, duration - fo, duration],
    [0, 1, 1, 0],
    {extrapolateLeft: "clamp", extrapolateRight: "clamp"}
  );
  return <AbsoluteFill style={{opacity}}>{children}</AbsoluteFill>;
};

/** Fade + slide up. */
export const Reveal: React.FC<{
  children: React.ReactNode;
  delay?: number;
  y?: number;
  style?: React.CSSProperties;
}> = ({children, delay = 0, y = 30, style}) => {
  const p = useEnter(delay);
  return (
    <div
      style={{
        opacity: p,
        transform: `translateY(${(1 - p) * y}px)`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** Text slides up from behind a mask. */
export const MaskText: React.FC<{
  children: React.ReactNode;
  delay?: number;
  style?: React.CSSProperties;
}> = ({children, delay = 0, style}) => {
  const p = useEnter(delay);
  return (
    <div style={{overflow: "hidden", paddingBottom: "0.14em", ...style}}>
      <div style={{transform: `translateY(${(1 - p) * 115}%)`}}>{children}</div>
    </div>
  );
};

/** A sentence revealed word by word. */
export const WordReveal: React.FC<{
  text: string;
  delay?: number;
  stagger?: number;
  style?: React.CSSProperties;
}> = ({text, delay = 0, stagger = 3, style}) => {
  const words = text.split(" ");
  return (
    <div style={{display: "flex", flexWrap: "wrap", columnGap: "0.28em", ...style}}>
      {words.map((w, i) => (
        <MaskText key={i} delay={delay + i * stagger}>
          {w}
        </MaskText>
      ))}
    </div>
  );
};

/** Small uppercase label. */
export const Label: React.FC<{
  children: React.ReactNode;
  delay?: number;
  color?: string;
}> = ({children, delay = 0, color = C.muted}) => (
  <Reveal delay={delay} y={14}>
    <div
      style={{
        fontSize: 24,
        fontWeight: 600,
        letterSpacing: 6,
        textTransform: "uppercase",
        color,
      }}
    >
      {children}
    </div>
  </Reveal>
);

/** Soft "pop" sound at a frame inside the current scene. */
export const Pop: React.FC<{at: number; volume?: number}> = ({at, volume = 0.28}) => (
  <Sequence from={Math.max(0, Math.round(at))} durationInFrames={20}>
    <Audio src={staticFile("pop.wav")} volume={volume} />
  </Sequence>
);

/** Persistent background: dotted grid + soft drifting color glows. */
export const Background: React.FC = () => {
  const frame = useCurrentFrame();

  const glow = (
    x: number,
    y: number,
    size: number,
    color: string,
    speed: number,
    phase: number
  ) => {
    const dx = Math.sin(frame * speed + phase) * 90;
    const dy = Math.cos(frame * speed * 0.8 + phase) * 60;
    return (
      <div
        style={{
          position: "absolute",
          left: x + dx - size / 2,
          top: y + dy - size / 2,
          width: size,
          height: size,
          borderRadius: "50%",
          background: `radial-gradient(circle, ${color} 0%, rgba(255,255,255,0) 68%)`,
          opacity: 0.2,
        }}
      />
    );
  };

  return (
    <AbsoluteFill>
      <AbsoluteFill
        style={{
          backgroundImage: `radial-gradient(${C.line} 1.5px, transparent 1.5px)`,
          backgroundSize: "48px 48px",
          opacity: 0.8,
        }}
      />
      {glow(1500, 200, 900, C.accent, 0.006, 0)}
      {glow(300, 900, 800, C.accent2, 0.005, 2)}
    </AbsoluteFill>
  );
};
