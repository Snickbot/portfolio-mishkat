# My Portfolio Video (Remotion)

A 2-minute, 16:9 (1920x1080, 30 fps) clean motion graphics portfolio video.
Music and sound effects are already included.

## What is in the video

| Time | Scene |
|------|-------|
| 0:00 – 0:08 | Intro: your name, role, tagline |
| 0:08 – 0:22 | About |
| 0:22 – 0:42 | Services (4 cards) |
| 0:42 – 1:30 | Selected work (3 projects, 16 s each) |
| 1:30 – 1:42 | Results by the numbers |
| 1:42 – 1:52 | Your process |
| 1:52 – 2:00 | Thank you + contact |

## Step 1 — Put the project on GitHub

1. Open your `my-video` repository on github.com (desktop site).
2. Tap **Add file → Upload files** and upload everything from this project
   (unzip it first). Keep the folders `src` and `public` as they are.
3. Tap **Commit changes**.

## Step 2 — Open a free Codespace

Repository page → **Code → Codespaces → Create codespace on main**.
Wait until you see a code editor with a terminal at the bottom.

## Step 3 — Install (one time)

Paste into the terminal, press Enter:

```
npm install
sudo apt-get update && sudo apt-get install -y libnss3 libdbus-1-3 libatk1.0-0 libgbm-dev libasound2t64 libxrandr2 libxkbcommon-dev libxfixes3 libxcomposite1 libxdamage1 libatk-bridge2.0-0 libpango-1.0-0 libcairo2 libcups2
```

If the second command says `libasound2t64` is not found, run it again with `libasound2`.

## Step 4 — Put in YOUR details

Open `src/config.ts`. Change the text between the quotes: name, role, services,
project titles, numbers, email. Nothing else needs editing.

### Add your real work (optional but recommended)

1. Upload your project videos or images into the `public` folder
   (for example `project1.mp4`).
2. In `src/config.ts`, remove the `//` in front of `media: "project1.mp4"`
   so it matches your file name.

## Step 5 — Preview

```
npm start
```

Codespaces shows a popup to open the forwarded port: tap **Open in Browser**.
You can play the video there and see every change as you save.

## Step 6 — Make the final MP4

Stop the preview (Ctrl + C), then:

```
npm run build
```

Rendering takes roughly 15–40 minutes in a free Codespace. When it finishes, the
file is `out/portfolio.mp4`. In the left file list, right-click it → **Download**.

## Change colors or timing

- Colors: `colors` block in `src/config.ts`.
- Scene lengths: `D` block in `src/timing.ts` (seconds × 30 = frames).

## Licence note

Remotion is free for individuals and small companies. Larger companies need a
Remotion company licence. See remotion.pro.
